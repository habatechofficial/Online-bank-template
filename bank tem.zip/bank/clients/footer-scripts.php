<!-- JS Scripts -->
  <script>
  // Sidebar Open/Close
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const closeSidebarBtn = document.getElementById('closeSidebar');

  sidebarToggle?.addEventListener('click', () => {
    sidebar?.classList.toggle('-translate-x-full');
  });

  closeSidebarBtn?.addEventListener('click', () => {
    sidebar?.classList.add('-translate-x-full');
  });

  // Submenu Toggle
  function toggleMenu(menuId) {
    const menu = document.getElementById(menuId);
    menu.classList.toggle('hidden');
  }

  // Theme Toggle
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  const htmlEl = document.documentElement;

  if (localStorage.getItem('theme') === 'dark') {
    htmlEl.classList.add('dark');
    themeIcon.className = 'bx bx-sun';
  } else {
    htmlEl.classList.remove('dark');
    themeIcon.className = 'bx bx-moon';
  }

  themeToggle?.addEventListener('click', () => {
    htmlEl.classList.toggle('dark');
    if (htmlEl.classList.contains('dark')) {
      themeIcon.className = 'bx bx-sun';
      localStorage.setItem('theme', 'dark');
    } else {
      themeIcon.className = 'bx bx-moon';
      localStorage.setItem('theme', 'light');
    }
  });

  // Profile Dropdown
  const profileButton = document.getElementById('profileButton');
  const profileDropdown = document.getElementById('profileDropdown');

  profileButton?.addEventListener('click', (e) => {
    e.stopPropagation();
    profileDropdown.classList.toggle('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!profileButton.contains(e.target)) {
      profileDropdown.classList.add('hidden');
    }
  });

  // Notification Dot
  const notificationButton = document.getElementById('notificationButton');
  const notificationDot = document.getElementById('notificationDot');

  notificationButton?.addEventListener('click', () => {
    notificationDot.style.display = 'none';
  });

  // Spending Chart
  const ctx = document.getElementById('spendingChart')?.getContext('2d');
  if (ctx) {
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Spending',
          data: [500, 700, 400, 800, 600, 750],
          borderColor: '#22c55e',
          backgroundColor: 'rgba(34,197,94,0.2)',
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });
  }
</script>