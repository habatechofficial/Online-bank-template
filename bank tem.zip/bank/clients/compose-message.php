<?php
// compose-message.php - RamzBank Compose New Message Page
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

<?php include 'header.php'; ?>

<main class="flex-1 p-6 overflow-y-auto">

  <h1 class="text-2xl font-bold mb-6">Compose Message</h1>

  <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">

    <form action="send-message.php" method="POST" class="space-y-6">

      <div>
        <label class="block mb-2 font-semibold" for="recipient">Recipient</label>
        <select id="recipient" name="recipient" class="w-full p-2 rounded-lg border dark:bg-gray-700">
          <option value="support">Support Team</option>
          <option value="loan">Loan Department</option>
          <option value="security">Security Department</option>
        </select>
      </div>

      <div>
        <label class="block mb-2 font-semibold" for="subject">Subject</label>
        <input type="text" name="subject" id="subject" class="w-full p-2 rounded-lg border dark:bg-gray-700" placeholder="Subject" required>
      </div>

      <div>
        <label class="block mb-2 font-semibold" for="message">Message</label>
        <textarea id="message" name="message" class="w-full p-2 rounded-lg border dark:bg-gray-700" rows="6" placeholder="Type your message..." required></textarea>
      </div>

      <div class="flex justify-end">
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg">Send Message</button>
      </div>

    </form>

  </div>

</main>

</div>

<?php include 'scripts.php'; ?>
</body>
</html>