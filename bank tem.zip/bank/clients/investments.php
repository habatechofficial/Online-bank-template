<?php
// investments.php - RamzBank Investments Page
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

<?php include 'header.php'; ?>

<main class="flex-1 p-6 overflow-y-auto">

  <div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Investments</h1>
    <a href="#" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">New Investment</a>
  </div>

  <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow overflow-x-auto">

    <h3 class="text-lg font-bold mb-4">Current Portfolio</h3>

    <table class="w-full table-auto">
      <thead>
        <tr class="text-left border-b">
          <th class="p-2">Asset</th>
          <th class="p-2">Amount Invested</th>
          <th class="p-2">Current Value</th>
          <th class="p-2">Performance</th>
        </tr>
      </thead>
      <tbody>
        <tr class="border-b">
          <td class="p-2">Stock - Apple (AAPL)</td>
          <td class="p-2">$2,000</td>
          <td class="p-2">$2,400</td>
          <td class="p-2 text-green-500">+20%</td>
        </tr>
        <tr class="border-b">
          <td class="p-2">Crypto - Bitcoin (BTC)</td>
          <td class="p-2">$1,500</td>
          <td class="p-2">$1,200</td>
          <td class="p-2 text-red-500">-20%</td>
        </tr>
        <!-- More investments -->
      </tbody>
    </table>

  </div>

</main>

</div>

<?php include 'scripts.php'; ?>
</body>
</html>