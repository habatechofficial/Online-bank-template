<?php
// open-new-account.php - RamzBank Open New Account
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

  <?php include 'sidebar.php'; ?>

  <div class="flex-1 flex flex-col min-h-screen">

    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 p-6 overflow-y-auto">
      <h1 class="text-2xl font-bold mb-6">Open New Account</h1>

      <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <form action="process-new-account.php" method="POST" class="space-y-6">

          <div>
            <label class="block mb-2 font-semibold" for="accountType">Account Type</label>
            <select id="accountType" name="accountType" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700">
              <option value="">Select an account type</option>
              <option value="checking">Checking Account</option>
              <option value="savings">Savings Account</option>
              <option value="business">Business Account</option>
            </select>
          </div>

          <div>
            <label class="block mb-2 font-semibold" for="initialDeposit">Initial Deposit ($)</label>
            <input type="number" id="initialDeposit" name="initialDeposit" min="0" required class="w-full p-2 rounded bg-gray-100 dark:bg-gray-700" placeholder="Enter amount">
          </div>

          <div class="text-right">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded">
              Submit Application
            </button>
          </div>

        </form>
      </div>

    </main>

  </div>

  <?php include 'footer-scripts.php'; ?>
</body>
</html>