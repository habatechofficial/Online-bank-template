<?php
// new-investment.php - RamzBank New Investment Page
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

<?php include 'header.php'; ?>

<main class="flex-1 p-6 overflow-y-auto">

  <h1 class="text-2xl font-bold mb-6">New Investment</h1>

  <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">

    <form action="process-new-investment.php" method="POST" class="space-y-6">

      <div>
        <label class="block mb-2 font-semibold" for="assetType">Asset Type</label>
        <select id="assetType" name="assetType" class="w-full p-2 rounded-lg border dark:bg-gray-700">
          <option value="stocks">Stocks</option>
          <option value="crypto">Cryptocurrency</option>
          <option value="bonds">Bonds</option>
          <option value="funds">Mutual Funds</option>
        </select>
      </div>

      <div>
        <label class="block mb-2 font-semibold" for="amount">Investment Amount</label>
        <input type="number" name="amount" id="amount" class="w-full p-2 rounded-lg border dark:bg-gray-700" placeholder="$0.00" required>
      </div>

      <div>
        <label class="block mb-2 font-semibold" for="notes">Notes (Optional)</label>
        <textarea id="notes" name="notes" class="w-full p-2 rounded-lg border dark:bg-gray-700" rows="3" placeholder="Any specific instructions..."></textarea>
      </div>

      <div class="flex justify-end">
        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">Invest Now</button>
      </div>

    </form>

  </div>

</main>

</div>

<?php include 'scripts.php'; ?>
</body>
</html>