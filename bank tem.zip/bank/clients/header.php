<!-- Navbar -->
    <header class="bg-white dark:bg-gray-800 shadow flex items-center justify-between px-6 py-4">

      <!-- Left: Hamburger and Brand -->
      <div class="flex items-center space-x-4">
        <button id="sidebarToggle" class="lg:hidden text-2xl text-gray-600 dark:text-gray-300">
          <i class='bx bx-menu'></i>
        </button>
        <div class="text-2xl font-bold text-green-600">Welcome, John Doe</div>
      </div>

      <!-- Right: Theme, Notifications, Profile -->
      <div class="flex items-center space-x-4">
        <button id="themeToggle" class="text-2xl">
          <i id="themeIcon" class="bx bx-moon"></i>
        </button>

        <button id="notificationButton" class="relative">
          <i class="bx bx-bell text-2xl"></i>
          <span id="notificationDot" class="absolute top-0 right-0 w-2 h-2 bg-red-600 rounded-full"></span>
        </button>

        <div class="relative">
          <button id="profileButton" class="flex items-center space-x-2">
            <img src="https://i.pravatar.cc/40" class="w-8 h-8 rounded-full" alt="Profile">
            <i class="bx bx-chevron-down text-xl"></i>
          </button>
          <div id="profileDropdown" class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-700 rounded shadow-lg hidden">
            <a href="profile.php" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600">Profile</a>
           <a href="settings.php" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600">Settings</a>
            <a href="logout.php" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 text-red-600">Logout</a>
          </div>
        </div>

      </div>
    </header>