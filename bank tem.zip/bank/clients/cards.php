<?php
// cards.php - RamzBank Client Cards Page
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include 'header.php'; ?>

  <!-- Main Content -->
  <main class="flex-1 p-6 overflow-y-auto">

    <div class="flex justify-between items-center mb-6">
      <h1 class="text-2xl font-bold">My Cards</h1>
      <a href="request-new-card.php" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg">Request New Card</a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <!-- Example Card -->
      <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <h3 class="text-lg font-bold mb-2">Visa Debit</h3>
        <p class="text-gray-500 mb-4">**** **** **** 1234</p>
        <p class="text-green-600 font-semibold">Active</p>
      </div>
      <!-- More Cards ... -->
    </div>

  </main>

</div>

<?php include 'scripts.php'; ?>
</body>
</html>