<?php
// statements.php - Account Statements
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

  <?php include 'sidebar.php'; ?>

  <div class="flex-1 flex flex-col min-h-screen">

    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 p-6 overflow-y-auto">

      <h1 class="text-2xl font-bold mb-6">Account Statements</h1>

      <!-- Statements Table -->
      <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow overflow-x-auto">
        <table class="w-full text-left">
          <thead>
            <tr>
              <th class="py-2 px-4">Date</th>
              <th class="py-2 px-4">Description</th>
              <th class="py-2 px-4">Amount</th>
              <th class="py-2 px-4">Balance</th>
              <th class="py-2 px-4">Download</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
            <tr>
              <td class="py-2 px-4">2025-04-01</td>
              <td class="py-2 px-4">Salary Deposit</td>
              <td class="py-2 px-4 text-green-500">+ $2,500.00</td>
              <td class="py-2 px-4">$12,450.75</td>
              <td class="py-2 px-4">
                <a href="#" class="text-blue-500 hover:underline">Download</a>
              </td>
            </tr>
            <tr>
              <td class="py-2 px-4">2025-04-05</td>
              <td class="py-2 px-4">Grocery Shopping</td>
              <td class="py-2 px-4 text-red-500">- $150.00</td>
              <td class="py-2 px-4">$12,300.75</td>
              <td class="py-2 px-4">
                <a href="#" class="text-blue-500 hover:underline">Download</a>
              </td>
            </tr>
            <!-- Add more rows dynamically -->
          </tbody>
        </table>
      </div>

    </main>

  </div>

  <?php include 'scripts.php'; ?>

</body>
</html>