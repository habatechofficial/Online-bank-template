<?php
// profile.php - RamzBank Client Profile
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

<?php include 'header.php'; ?>

<main class="flex-1 p-6 overflow-y-auto">

  <h1 class="text-2xl font-bold mb-6">My Profile</h1>

  <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md max-w-4xl mx-auto">

    <!-- Profile Picture -->
    <div class="flex flex-col items-center mb-8">
      <img src="uploads/profile-placeholder.png" alt="Profile Picture" class="w-32 h-32 rounded-full object-cover border-4 border-green-500 shadow-md">
      <h2 class="mt-4 text-xl font-semibold">John Doe</h2>
      <p class="text-gray-500 dark:text-gray-400">Client since 2021</p>
    </div>

    <!-- Profile Details -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

      <div>
        <label class="block text-sm font-semibold mb-2">First Name</label>
        <input type="text" value="John" readonly class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Last Name</label>
        <input type="text" value="Doe" readonly class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Email</label>
        <input type="email" value="john.doe@example.com" readonly class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Phone Number</label>
        <input type="text" value="+1 234 567 890" readonly class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Country</label>
        <input type="text" value="United States" readonly class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Address</label>
        <input type="text" value="123 Main Street, New York, NY" readonly class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

    </div>

    <!-- Edit Button -->
    <div class="flex justify-end mt-8">
      <a href="edit-profile.php" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">Edit Profile</a>
    </div>

  </div>

</main>

</div>

<?php include 'scripts.php'; ?>

</body>
</html>