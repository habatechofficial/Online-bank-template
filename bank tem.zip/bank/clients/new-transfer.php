<?php
// new-transfer.php - RamzBank New Transfer Page
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include 'header.php'; ?>

  <main class="flex-1 p-6 overflow-y-auto">

    <h1 class="text-2xl font-bold mb-6">New Transfer</h1>

    <form action="process-new-transfer.php" method="POST" class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow space-y-4">

      <div>
        <label class="block mb-2 font-semibold">Recipient Name</label>
        <input type="text" name="recipientName" class="w-full p-2 border rounded" required>
      </div>

      <div>
        <label class="block mb-2 font-semibold">Recipient Account Number</label>
        <input type="text" name="recipientAccount" class="w-full p-2 border rounded" required>
      </div>

      <div>
        <label class="block mb-2 font-semibold">Amount</label>
        <input type="number" name="amount" step="0.01" class="w-full p-2 border rounded" required>
      </div>

      <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">Send Money</button>

    </form>

  </main>

</div>

<?php include 'scripts.php'; ?>
</body>
</html>