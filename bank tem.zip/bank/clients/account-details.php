<?php
// account-details.php - RamzBank Client Account Details
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

  <?php include 'sidebar.php'; ?>

  <div class="flex-1 flex flex-col min-h-screen">

    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 p-6 overflow-y-auto">
      <h1 class="text-2xl font-bold mb-6">Account Details</h1>

      <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow mb-8">
        <h3 class="text-lg font-bold mb-4">Checking Account - **** 5678</h3>
        <p class="mb-2"><strong>Balance:</strong> <span class="text-green-600">$5,430.20</span></p>
        <p class="mb-2"><strong>Account Type:</strong> Checking</p>
        <p class="mb-2"><strong>Opened:</strong> January 15, 2020</p>
        <p><strong>Status:</strong> Active</p>
      </div>

      <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <h3 class="text-lg font-bold mb-4">Recent Transactions</h3>
        <ul class="space-y-4">
          <li class="flex justify-between">
            <span>Walmart Purchase</span>
            <span class="text-red-500">- $90.00</span>
          </li>
          <li class="flex justify-between">
            <span>Deposit</span>
            <span class="text-green-500">+ $1,200.00</span>
          </li>
          <li class="flex justify-between">
            <span>Utility Payment</span>
            <span class="text-red-500">- $45.75</span>
          </li>
          <li class="flex justify-between">
            <span>Gym Membership</span>
            <span class="text-red-500">- $30.00</span>
          </li>
        </ul>
      </div>

    </main>

  </div>

  <?php include 'footer-scripts.php'; ?>
</body>
</html>