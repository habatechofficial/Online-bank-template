<?php
// messages.php - RamzBank Messages Page
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

<?php include 'header.php'; ?>

<main class="flex-1 p-6 overflow-y-auto">

  <h1 class="text-2xl font-bold mb-6">Messages</h1>

  <div class="space-y-6">

    <!-- Message 1 -->
    <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
      <div class="flex justify-between items-center mb-2">
        <h3 class="text-lg font-bold">Support Team</h3>
        <span class="text-sm text-gray-500">2025-04-20</span>
      </div>
      <p class="text-gray-600 dark:text-gray-300">Your recent loan application has been approved. Please review the attached documents for next steps.</p>
    </div>

    <!-- Message 2 -->
    <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
      <div class="flex justify-between items-center mb-2">
        <h3 class="text-lg font-bold">Security Alert</h3>
        <span class="text-sm text-gray-500">2025-04-18</span>
      </div>
      <p class="text-gray-600 dark:text-gray-300">A new device has been used to log in to your account. If this was not you, please secure your account immediately.</p>
    </div>

    <!-- More messages -->

  </div>

</main>

</div>

<?php include 'scripts.php'; ?>
</body>
</html>