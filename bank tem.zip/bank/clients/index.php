<?php
// dashboard.php - RamzBank Client Dashboard
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

  <?php include 'sidebar.php'; ?>

  <div class="flex-1 flex flex-col min-h-screen">

  <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 p-6 overflow-y-auto">

      <!-- Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">

        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Total Balance</h3>
          <p class="text-2xl text-green-600 font-semibold">$12,450.75</p>
        </div>

        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Active Cards</h3>
          <p class="text-2xl text-green-600 font-semibold">3 Cards</p>
        </div>

        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Loan Balance</h3>
          <p class="text-2xl text-green-600 font-semibold">$5,300.00</p>
        </div>

        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Transactions</h3>
          <p class="text-2xl text-green-600 font-semibold">+42 this month</p>
        </div>

      </div>

      <!-- Charts + Recent Transactions -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- Chart -->
        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow col-span-2">
          <h3 class="text-lg font-bold mb-4">Spending Overview</h3>
          <canvas id="spendingChart" height="100"></canvas>
        </div>

        <!-- Recent Transactions -->
        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-4">Recent Transactions</h3>
          <ul class="space-y-4">
            <li class="flex justify-between">
              <span>Amazon Purchase</span>
              <span class="text-red-500">- $120.00</span>
            </li>
            <li class="flex justify-between">
              <span>Salary Deposit</span>
              <span class="text-green-500">+ $2,500.00</span>
            </li>
            <li class="flex justify-between">
              <span>Electricity Bill</span>
              <span class="text-red-500">- $80.25</span>
            </li>
            <li class="flex justify-between">
              <span>Netflix Subscription</span>
              <span class="text-red-500">- $15.99</span>
            </li>
          </ul>
        </div>

      </div>

    </main>

  </div>

  <!-- JS Scripts -->
  <script>
  // Sidebar Open/Close
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const closeSidebarBtn = document.getElementById('closeSidebar');

  sidebarToggle?.addEventListener('click', () => {
    sidebar?.classList.toggle('-translate-x-full');
  });

  closeSidebarBtn?.addEventListener('click', () => {
    sidebar?.classList.add('-translate-x-full');
  });

  // Submenu Toggle
  function toggleMenu(menuId) {
    const menu = document.getElementById(menuId);
    menu.classList.toggle('hidden');
  }

  // Theme Toggle
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  const htmlEl = document.documentElement;

  if (localStorage.getItem('theme') === 'dark') {
    htmlEl.classList.add('dark');
    themeIcon.className = 'bx bx-sun';
  } else {
    htmlEl.classList.remove('dark');
    themeIcon.className = 'bx bx-moon';
  }

  themeToggle?.addEventListener('click', () => {
    htmlEl.classList.toggle('dark');
    if (htmlEl.classList.contains('dark')) {
      themeIcon.className = 'bx bx-sun';
      localStorage.setItem('theme', 'dark');
    } else {
      themeIcon.className = 'bx bx-moon';
      localStorage.setItem('theme', 'light');
    }
  });

  // Profile Dropdown
  const profileButton = document.getElementById('profileButton');
  const profileDropdown = document.getElementById('profileDropdown');

  profileButton?.addEventListener('click', (e) => {
    e.stopPropagation();
    profileDropdown.classList.toggle('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!profileButton.contains(e.target)) {
      profileDropdown.classList.add('hidden');
    }
  });

  // Notification Dot
  const notificationButton = document.getElementById('notificationButton');
  const notificationDot = document.getElementById('notificationDot');

  notificationButton?.addEventListener('click', () => {
    notificationDot.style.display = 'none';
  });

  // Spending Chart
  const ctx = document.getElementById('spendingChart')?.getContext('2d');
  if (ctx) {
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Spending',
          data: [500, 700, 400, 800, 600, 750],
          borderColor: '#22c55e',
          backgroundColor: 'rgba(34,197,94,0.2)',
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });
  }
</script>

</body>
</html>