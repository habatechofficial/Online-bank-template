<?php
// settings.php - RamzBank Settings Page
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

<?php include 'header.php'; ?>

<main class="flex-1 p-6 overflow-y-auto">

  <h1 class="text-2xl font-bold mb-6">Account Settings</h1>

  <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">

    <!-- Tabs -->
    <div class="mb-6 border-b dark:border-gray-700">
      <nav class="flex space-x-8" id="tabs-nav">
        <button class="tab-link text-gray-600 dark:text-gray-300 py-2 px-4 border-b-2 border-transparent hover:border-green-500 focus:outline-none active" data-tab="profile">Profile</button>
        <button class="tab-link text-gray-600 dark:text-gray-300 py-2 px-4 border-b-2 border-transparent hover:border-green-500 focus:outline-none" data-tab="security">Security</button>
        <button class="tab-link text-gray-600 dark:text-gray-300 py-2 px-4 border-b-2 border-transparent hover:border-green-500 focus:outline-none" data-tab="notifications">Notifications</button>
      </nav>
    </div>

    <!-- Tabs Content -->
    <div id="tabs-content">

      <!-- Profile Tab -->
      <div class="tab-pane" id="profile">
        <form action="update-profile.php" method="POST" class="space-y-6">

          <div>
            <label class="block mb-2 font-semibold" for="fullName">Full Name</label>
            <input type="text" name="fullName" id="fullName" class="w-full p-2 rounded-lg border dark:bg-gray-700" value="John Doe">
          </div>

          <div>
            <label class="block mb-2 font-semibold" for="email">Email Address</label>
            <input type="email" name="email" id="email" class="w-full p-2 rounded-lg border dark:bg-gray-700" value="john@example.com">
          </div>

          <div class="flex justify-end">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">Save Changes</button>
          </div>

        </form>
      </div>

      <!-- Security Tab -->
      <div class="tab-pane hidden" id="security">
        <form action="update-password.php" method="POST" class="space-y-6">

          <div>
            <label class="block mb-2 font-semibold" for="currentPassword">Current Password</label>
            <input type="password" name="currentPassword" id="currentPassword" class="w-full p-2 rounded-lg border dark:bg-gray-700" required>
          </div>

          <div>
            <label class="block mb-2 font-semibold" for="newPassword">New Password</label>
            <input type="password" name="newPassword" id="newPassword" class="w-full p-2 rounded-lg border dark:bg-gray-700" required>
          </div>

          <div>
            <label class="block mb-2 font-semibold" for="confirmPassword">Confirm New Password</label>
            <input type="password" name="confirmPassword" id="confirmPassword" class="w-full p-2 rounded-lg border dark:bg-gray-700" required>
          </div>

          <div class="flex justify-end">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">Update Password</button>
          </div>

        </form>
      </div>

      <!-- Notifications Tab -->
      <div class="tab-pane hidden" id="notifications">
        <form action="update-notifications.php" method="POST" class="space-y-6">

          <div class="flex items-center">
            <input type="checkbox" id="emailNotifications" name="emailNotifications" class="mr-3" checked>
            <label for="emailNotifications" class="font-semibold">Email Notifications</label>
          </div>

          <div class="flex items-center">
            <input type="checkbox" id="smsNotifications" name="smsNotifications" class="mr-3">
            <label for="smsNotifications" class="font-semibold">SMS Notifications</label>
          </div>

          <div class="flex items-center">
            <input type="checkbox" id="pushNotifications" name="pushNotifications" class="mr-3" checked>
            <label for="pushNotifications" class="font-semibold">Push Notifications</label>
          </div>

          <div class="flex justify-end">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">Save Preferences</button>
          </div>

        </form>
      </div>

    </div>

  </div>

</main>

</div>

<?php include 'scripts.php'; ?>

<!-- Custom Tab Switcher -->
<script>
  const tabLinks = document.querySelectorAll('.tab-link');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabLinks.forEach(link => {
    link.addEventListener('click', () => {
      const tab = link.getAttribute('data-tab');

      tabLinks.forEach(btn => btn.classList.remove('active', 'border-green-500', 'text-green-600'));
      tabPanes.forEach(pane => pane.classList.add('hidden'));

      document.getElementById(tab).classList.remove('hidden');
      link.classList.add('active', 'border-green-500', 'text-green-600');
    });
  });
</script>

<!-- Custom CSS for active tabs -->
<style>
  .tab-link.active {
    border-color: #22c55e;
    color: #22c55e;
  }
</style>

</body>
</html>