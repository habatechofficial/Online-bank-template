<?php
// edit-profile.php - RamzBank Edit Client Profile
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

<?php include 'sidebar.php'; ?>

<div class="flex-1 flex flex-col min-h-screen">

<?php include 'header.php'; ?>

<main class="flex-1 p-6 overflow-y-auto">

  <h1 class="text-2xl font-bold mb-6">Edit Profile</h1>

  <form action="process-edit-profile.php" method="POST" enctype="multipart/form-data" class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md max-w-4xl mx-auto">

    <!-- Profile Picture Upload -->
    <div class="flex flex-col items-center mb-8">
      <img src="uploads/profile-placeholder.png" alt="Current Profile" class="w-32 h-32 rounded-full object-cover border-4 border-green-500 shadow-md mb-4" id="profilePreview">
      
      <label class="block text-sm font-semibold mb-2">Upload New Profile Picture</label>
      <input type="file" name="profile_picture" accept="image/*" class="text-sm mt-2 text-gray-700 dark:text-gray-300">
    </div>

    <!-- Profile Details Form -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

      <div>
        <label class="block text-sm font-semibold mb-2">First Name</label>
        <input type="text" name="first_name" value="John" required class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Last Name</label>
        <input type="text" name="last_name" value="Doe" required class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Email</label>
        <input type="email" name="email" value="john.doe@example.com" required class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Phone Number</label>
        <input type="text" name="phone" value="+1 234 567 890" required class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Country</label>
        <input type="text" name="country" value="United States" required class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

      <div>
        <label class="block text-sm font-semibold mb-2">Address</label>
        <input type="text" name="address" value="123 Main Street, New York, NY" required class="w-full p-3 rounded-lg border dark:bg-gray-700">
      </div>

    </div>

    <!-- Save Changes Button -->
    <div class="flex justify-end mt-8">
      <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg">Save Changes</button>
    </div>

  </form>

</main>

</div>

<?php include 'scripts.php'; ?>

<!-- JS to preview uploaded profile picture -->
<script>
const profilePreview = document.getElementById('profilePreview');
const fileInput = document.querySelector('input[name="profile_picture"]');

fileInput.addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (file) {
    profilePreview.src = URL.createObjectURL(file);
  }
});
</script>

</body>
</html>