<?php
// accounts.php - RamzBank Client Accounts
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

  <?php include 'sidebar.php'; ?>

  <div class="flex-1 flex flex-col min-h-screen">

    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 p-6 overflow-y-auto">
      <h1 class="text-2xl font-bold mb-6">My Accounts</h1>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        <!-- Account Card -->
        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Checking Account</h3>
          <p class="text-gray-500 dark:text-gray-400 mb-4">**** 5678</p>
          <p class="text-2xl text-green-600 font-semibold">$5,430.20</p>
          <a href="account-details.php" class="text-blue-600 hover:underline mt-4 inline-block">View Details</a>
        </div>

        <!-- Account Card -->
        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Savings Account</h3>
          <p class="text-gray-500 dark:text-gray-400 mb-4">**** 1234</p>
          <p class="text-2xl text-green-600 font-semibold">$10,250.00</p>
          <a href="account-details.php" class="text-blue-600 hover:underline mt-4 inline-block">View Details</a>
        </div>

        <!-- Account Card -->
        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
          <h3 class="text-lg font-bold mb-2">Business Account</h3>
          <p class="text-gray-500 dark:text-gray-400 mb-4">**** 9012</p>
          <p class="text-2xl text-green-600 font-semibold">$2,780.50</p>
          <a href="account-details.php" class="text-blue-600 hover:underline mt-4 inline-block">View Details</a>
        </div>

      </div>

    </main>

  </div>

  <?php include 'footer-scripts.php'; ?>
</body>
</html>