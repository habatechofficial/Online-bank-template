<?php
// process-edit-profile.php - Handle Profile Edit

session_start(); // Start session if you need to use session messages (optional)

// Connect to your database
include 'db.php'; // (Assuming you have a db.php file that connects to MySQL)

// Fetch submitted data
$first_name = trim($_POST['first_name']);
$last_name = trim($_POST['last_name']);
$email = trim($_POST['email']);
$phone = trim($_POST['phone']);
$country = trim($_POST['country']);
$address = trim($_POST['address']);

// Assume you have the client ID from session or login
$client_id = $_SESSION['client_id'] ?? 1; // fallback for testing

// Handle Profile Picture Upload
$profile_picture = '';

if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
    $file_tmp = $_FILES['profile_picture']['tmp_name'];
    $file_name = basename($_FILES['profile_picture']['name']);
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if (in_array($file_ext, $allowed_extensions)) {
        $new_filename = 'uploads/profile_' . time() . '.' . $file_ext;
        if (move_uploaded_file($file_tmp, $new_filename)) {
            $profile_picture = $new_filename;
        } else {
            echo "Error uploading file.";
            exit;
        }
    } else {
        echo "Invalid file type. Only JPG, PNG, GIF allowed.";
        exit;
    }
}

// Update Client Information
$sql = "UPDATE clients SET 
          first_name = ?, 
          last_name = ?, 
          email = ?, 
          phone = ?, 
          country = ?, 
          address = ?" . ($profile_picture ? ", profile_picture = ?" : "") . " 
        WHERE id = ?";

$stmt = $conn->prepare($sql);

if ($profile_picture) {
    $stmt->bind_param("sssssssi", $first_name, $last_name, $email, $phone, $country, $address, $profile_picture, $client_id);
} else {
    $stmt->bind_param("ssssssi", $first_name, $last_name, $email, $phone, $country, $address, $client_id);
}

if ($stmt->execute()) {
    // Redirect back with success
    $_SESSION['success'] = "Profile updated successfully.";
    header("Location: profile.php");
    exit;
} else {
    echo "Error updating profile: " . $conn->error;
    exit;
}
?>