<?php
// notifications.php - Notifications
?>

<?php include 'head.php'; ?>

<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 flex">

  <?php include 'sidebar.php'; ?>

  <div class="flex-1 flex flex-col min-h-screen">

    <?php include 'header.php'; ?>

    <!-- Main Content -->
    <main class="flex-1 p-6 overflow-y-auto">

      <h1 class="text-2xl font-bold mb-6">Notifications</h1>

      <!-- Notifications List -->
      <div class="space-y-4">

        <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex justify-between items-center">
          <div>
            <h3 class="font-semibold">New Transfer Received</h3>
            <p class="text-sm text-gray-500 dark:text-gray-400">You received $500 from John Doe. (2 hours ago)</p>
          </div>
          <button class="text-blue-500 hover:underline">View</button>
        </div>

        <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex justify-between items-center">
          <div>
            <h3 class="font-semibold">Loan Payment Reminder</h3>
            <p class="text-sm text-gray-500 dark:text-gray-400">Your loan installment is due in 3 days. (1 day ago)</p>
          </div>
          <button class="text-blue-500 hover:underline">View</button>
        </div>

        <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex justify-between items-center">
          <div>
            <h3 class="font-semibold">New Card Issued</h3>
            <p class="text-sm text-gray-500 dark:text-gray-400">Your new debit card is on the way! (5 days ago)</p>
          </div>
          <button class="text-blue-500 hover:underline">View</button>
        </div>

      </div>

    </main>

  </div>

  <?php include 'scripts.php'; ?>

</body>
</html>