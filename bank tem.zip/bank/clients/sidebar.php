<?php
// sidebar.php - RamzBank Sidebar
?>

<aside id="sidebar" class="bg-white dark:bg-gray-800 w-64 min-h-screen flex flex-col shadow-lg fixed lg:relative transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out z-40">

  <!-- Top: Logo + Close Button (Mobile Only) -->
  <div class="flex items-center justify-between h-20 px-4 border-b dark:border-gray-700">
    <h1 class="text-2xl font-bold text-green-600">RamzBank</h1>
    <button id="closeSidebar" class="lg:hidden text-gray-600 dark:text-gray-300 text-2xl">
      <i class="bx bx-x"></i>
    </button>
  </div>

  <!-- Navigation -->
  <nav class="flex-1 overflow-y-auto p-4">
    <ul class="space-y-2">

      <!-- Dashboard -->
      <li>
        <a href="dashboard.php" class="flex items-center p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <i class="bx bx-home text-xl mr-3"></i> Dashboard
        </a>
      </li>

      <!-- Accounts -->
      <li>
        <button onclick="toggleMenu('accountsMenu')" class="w-full flex items-center justify-between p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <span class="flex items-center">
            <i class="bx bx-wallet text-xl mr-3"></i> Accounts
          </span>
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="accountsMenu" class="ml-8 mt-2 space-y-2 hidden">
          <a href="accounts.php" class="block hover:text-green-600">My Accounts</a>
          <a href="account-details.php" class="block hover:text-green-600">Account Details</a>
          <a href="open-new-account.php" class="block hover:text-green-600">Open New Account</a>
        </div>
      </li>

      <!-- Cards -->
      <li>
        <button onclick="toggleMenu('cardsMenu')" class="w-full flex items-center justify-between p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <span class="flex items-center">
            <i class="bx bx-credit-card text-xl mr-3"></i> Cards
          </span>
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="cardsMenu" class="ml-8 mt-2 space-y-2 hidden">
          <a href="cards.php" class="block hover:text-green-600">Manage Cards</a>
          <a href="request-new-card.php" class="block hover:text-green-600">Request Card</a>
        </div>
      </li>

      <!-- Transfers -->
      <li>
        <button onclick="toggleMenu('transfersMenu')" class="w-full flex items-center justify-between p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <span class="flex items-center">
            <i class="bx bx-transfer text-xl mr-3"></i> Transfers
          </span>
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="transfersMenu" class="ml-8 mt-2 space-y-2 hidden">
          <a href="transfers.php" class="block hover:text-green-600">Transfers</a>
          <a href="new-transfer.php" class="block hover:text-green-600">New Transfer</a>
          <a href="transfer-history.php" class="block hover:text-green-600">History</a>
        </div>
      </li>

      <!-- Payments -->
      <li>
        <button onclick="toggleMenu('paymentsMenu')" class="w-full flex items-center justify-between p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <span class="flex items-center">
            <i class="bx bx-receipt text-xl mr-3"></i> Payments
          </span>
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="paymentsMenu" class="ml-8 mt-2 space-y-2 hidden">
          <a href="payments.php" class="block hover:text-green-600">Pay Bills</a>
          <a href="payment-history.php" class="block hover:text-green-600">Payment History</a>
        </div>
      </li>

      <!-- Loans -->
      <li>
        <button onclick="toggleMenu('loansMenu')" class="w-full flex items-center justify-between p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <span class="flex items-center">
            <i class="bx bx-dollar-circle text-xl mr-3"></i> Loans
          </span>
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="loansMenu" class="ml-8 mt-2 space-y-2 hidden">
          <a href="loans.php" class="block hover:text-green-600">My Loans</a>
          <a href="loan-application.php" class="block hover:text-green-600">Apply for Loan</a>
          <a href="loan-history.php" class="block hover:text-green-600">Loan History</a>
        </div>
      </li>

      <!-- Investments -->
      <li>
        <a href="investments.php" class="flex items-center p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <i class="bx bx-bar-chart text-xl mr-3"></i> Investments
        </a>
      </li>

      <!-- Messages / Support -->
      <li>
        <a href="messages.php" class="flex items-center p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <i class="bx bx-envelope text-xl mr-3"></i> Messages
        </a>
      </li>

      <!-- Settings -->
      <li>
        <a href="settings.php" class="flex items-center p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <i class="bx bx-cog text-xl mr-3"></i> Settings
        </a>
      </li>

      <!-- Statements -->
      <li>
        <a href="statements.php" class="flex items-center p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <i class="bx bx-file text-xl mr-3"></i> Statements
        </a>
      </li>

      <!-- Notifications -->
      <li>
        <a href="notifications.php" class="flex items-center p-3 rounded hover:bg-green-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200">
          <i class="bx bx-bell text-xl mr-3"></i> Notifications
        </a>
      </li>

      <!-- Logout -->
      <li>
        <a href="logout.php" class="flex items-center p-3 text-red-600 hover:bg-red-100 dark:hover:bg-gray-700">
          <i class="bx bx-log-out text-xl mr-3"></i> Logout
        </a>
      </li>

    </ul>
  </nav>

</aside>
