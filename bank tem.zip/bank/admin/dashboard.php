<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Dashboard</h1>

    <!-- Cards Section -->
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-6">
      <!-- Card 1 -->
      <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex items-center">
        <div class="p-3 bg-blue-100 dark:bg-blue-900 rounded-full text-blue-500 dark:text-blue-300 mr-4">
          <i class="bx bx-user text-2xl"></i>
        </div>
        <div>
          <p class="text-sm text-gray-500 dark:text-gray-400">Total Users</p>
          <p class="text-lg font-semibold text-gray-800 dark:text-white">1,250</p>
        </div>
      </div>
      <!-- Card 2 -->
      <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex items-center">
        <div class="p-3 bg-green-100 dark:bg-green-900 rounded-full text-green-500 dark:text-green-300 mr-4">
          <i class="bx bx-dollar-circle text-2xl"></i>
        </div>
        <div>
          <p class="text-sm text-gray-500 dark:text-gray-400">Total Transactions</p>
          <p class="text-lg font-semibold text-gray-800 dark:text-white">$245,000</p>
        </div>
      </div>
      <!-- Card 3 -->
      <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex items-center">
        <div class="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-full text-yellow-500 dark:text-yellow-300 mr-4">
          <i class="bx bx-credit-card text-2xl"></i>
        </div>
        <div>
          <p class="text-sm text-gray-500 dark:text-gray-400">Active Cards</p>
          <p class="text-lg font-semibold text-gray-800 dark:text-white">580</p>
        </div>
      </div>
      <!-- Card 4 -->
      <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow flex items-center">
        <div class="p-3 bg-red-100 dark:bg-red-900 rounded-full text-red-500 dark:text-red-300 mr-4">
          <i class="bx bx-error-circle text-2xl"></i>
        </div>
        <div>
          <p class="text-sm text-gray-500 dark:text-gray-400">Pending Tickets</p>
          <p class="text-lg font-semibold text-gray-800 dark:text-white">34</p>
        </div>
      </div>
    </div>

    <!-- Charts Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">Transactions Over Time</h2>
        <canvas id="transactionsChart" height="200"></canvas>
      </div>

      <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">New Users This Month</h2>
        <canvas id="usersChart" height="200"></canvas>
      </div>
    </div>

    <!-- Recent Transactions Table -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 class="text-2xl font-bold text-gray-800 dark:text-white mb-4">Recent Transactions</h2>

      <div class="overflow-x-auto">
        <table class="min-w-full text-left text-sm">
          <thead class="bg-gray-100 dark:bg-gray-700">
            <tr>
              <th class="px-4 py-2 font-semibold text-gray-700 dark:text-gray-300">User</th>
              <th class="px-4 py-2 font-semibold text-gray-700 dark:text-gray-300">Amount</th>
              <th class="px-4 py-2 font-semibold text-gray-700 dark:text-gray-300">Status</th>
              <th class="px-4 py-2 font-semibold text-gray-700 dark:text-gray-300">Date</th>
            </tr>
          </thead>
          <tbody>
            <tr class="border-b dark:border-gray-700">
              <td class="px-4 py-3 text-gray-800 dark:text-white">John Doe</td>
              <td class="px-4 py-3 text-green-500">$2,500</td>
              <td class="px-4 py-3 text-yellow-500">Pending</td>
              <td class="px-4 py-3 text-gray-600 dark:text-gray-400">Apr 25, 2025</td>
            </tr>
            <tr class="border-b dark:border-gray-700">
              <td class="px-4 py-3 text-gray-800 dark:text-white">Sarah Lee</td>
              <td class="px-4 py-3 text-green-500">$1,200</td>
              <td class="px-4 py-3 text-green-500">Completed</td>
              <td class="px-4 py-3 text-gray-600 dark:text-gray-400">Apr 24, 2025</td>
            </tr>
            <tr class="border-b dark:border-gray-700">
              <td class="px-4 py-3 text-gray-800 dark:text-white">Mike Brown</td>
              <td class="px-4 py-3 text-green-500">$3,400</td>
              <td class="px-4 py-3 text-red-500">Failed</td>
              <td class="px-4 py-3 text-gray-600 dark:text-gray-400">Apr 23, 2025</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

  </main>

</div>

<!-- Scripts -->
<?php include('scripts.php'); ?>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  const ctx1 = document.getElementById('transactionsChart').getContext('2d');
  const transactionsChart = new Chart(ctx1, {
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [{
        label: 'Transactions ($)',
        data: [12000, 19000, 3000, 5000, 20000, 30000],
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 2,
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  });

  const ctx2 = document.getElementById('usersChart').getContext('2d');
  const usersChart = new Chart(ctx2, {
    type: 'bar',
    data: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
      datasets: [{
        label: 'New Users',
        data: [50, 75, 150, 100],
        backgroundColor: 'rgba(16, 185, 129, 0.6)',
        borderColor: 'rgba(5, 150, 105, 1)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  });
</script>

</body>
</html>