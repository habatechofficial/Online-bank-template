<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Financial Reports</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <canvas id="financialChart" height="100"></canvas>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('financialChart').getContext('2d');
const financialChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        datasets: [{
            label: 'Revenue',
            data: [12000, 15000, 17000, 14000, 20000],
            backgroundColor: 'rgba(59, 130, 246, 0.7)',
            borderRadius: 5
        }]
    },
    options: {
        responsive: true,
        plugins: {
          legend: { display: false }
        }
    }
});
</script>

</body>
</html>