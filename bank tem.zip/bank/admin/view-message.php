<?php
// profile.php
?>

<!-- Head -->
<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="flex-1 flex flex-col min-h-screen">

  <!-- Topbar -->
  <?php include('topbar.php'); ?>

  
  





<main class="flex-1 p-6">

  <!-- view-message.php -->




  <div class="mb-8 flex justify-between items-center">
    <div>
      <h1 class="text-3xl font-bold text-gray-800 dark:text-white">View Message</h1>
      <p class="text-gray-600 dark:text-gray-400 mt-2">Respond to user inquiries.</p>
    </div>
    <a href="messages.php" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg">Back to Messages</a>
  </div>

  <div class="bg-white dark:bg-gray-800 rounded-xl shadow p-6">
    <h2 class="text-2xl font-semibold text-gray-800 dark:text-white mb-4">Account Verification Issue</h2>
    <div class="text-gray-600 dark:text-gray-400 mb-6">
      <p><strong>From:</strong> John Doe (johndoe@example.com)</p>
      <p><strong>Date:</strong> 2025-04-25 10:24 AM</p>
    </div>

    <div class="text-gray-700 dark:text-gray-300 leading-relaxed">
      Hello, I am unable to verify my bank account. Please help me to complete the verification process. Thank you.
    </div>

    <div class="mt-8">
      <textarea class="w-full p-4 rounded-lg border border-gray-300 dark:border-gray-700 dark:bg-gray-700 dark:text-white resize-none" rows="5" placeholder="Write your response..."></textarea>
      <button class="mt-4 px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg">Send Response</button>
    </div>
  </div>

</main>
</div>

<!-- JavaScript -->
<script>
// Preloader (optional if needed)

// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const htmlEl = document.documentElement;

if (localStorage.getItem('theme') === 'dark') {
  htmlEl.classList.add('dark');
  themeIcon.className = 'bx bx-sun';
} else {
  htmlEl.classList.remove('dark');
  themeIcon.className = 'bx bx-moon';
}

themeToggle.addEventListener('click', () => {
  htmlEl.classList.toggle('dark');
  if (htmlEl.classList.contains('dark')) {
    themeIcon.className = 'bx bx-sun';
    localStorage.setItem('theme', 'dark');
  } else {
    themeIcon.className = 'bx bx-moon';
    localStorage.setItem('theme', 'light');
  }
});

// Sidebar Toggle
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.getElementById('sidebar');
sidebarToggle?.addEventListener('click', () => {
  sidebar.classList.toggle('sidebar-collapsed');
});

// Mobile Sidebar
const mobileSidebarButton = document.getElementById('mobileSidebarButton');
mobileSidebarButton?.addEventListener('click', () => {
  sidebar.classList.toggle('sidebar-collapsed');
});

// Dropdowns
document.querySelectorAll('#usersDropdown, #settingsDropdown').forEach(drop => {
  const link = drop.querySelector('a');
  const submenu = drop.querySelector('div');
  link.addEventListener('click', e => {
    e.preventDefault();
    submenu.classList.toggle('hidden');
  });
});

// Profile Dropdown
const profileButton = document.getElementById('profileButton');
const profileDropdown = document.getElementById('profileDropdown');
profileButton?.addEventListener('click', (e) => {
  e.stopPropagation();
  profileDropdown.classList.toggle('hidden');
});
document.addEventListener('click', (e) => {
  if (!profileButton.contains(e.target)) {
    profileDropdown.classList.add('hidden');
  }
});

// Notification Dot
const notificationButton = document.getElementById('notificationButton');
const notificationDot = document.getElementById('notificationDot');
notificationButton?.addEventListener('click', () => {
  notificationDot.style.display = 'none';
});
</script>

</body>
</html>