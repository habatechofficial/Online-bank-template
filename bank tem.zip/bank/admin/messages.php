<?php
// profile.php
?>

<!-- Head -->
<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="flex-1 flex flex-col min-h-screen">

  <!-- Topbar -->
  <?php include('topbar.php'); ?>

  
  


<!-- messages.php -->


<main class="flex-1 p-6">

  <div class="mb-8">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white">Messages</h1>
    <p class="text-gray-600 dark:text-gray-400 mt-2">View and respond to customer messages.</p>
  </div>

  <div class="bg-white dark:bg-gray-800 rounded-xl shadow p-6">
    <div class="overflow-x-auto">
      <table class="min-w-full table-auto">
        <thead>
          <tr class="text-gray-700 dark:text-gray-300 text-left">
            <th class="py-3 px-6">#</th>
            <th class="py-3 px-6">Sender</th>
            <th class="py-3 px-6">Subject</th>
            <th class="py-3 px-6">Received</th>
            <th class="py-3 px-6">Action</th>
          </tr>
        </thead>
        <tbody class="text-gray-600 dark:text-gray-400">
          <?php for($i=1;$i<=5;$i++): ?>
          <tr class="border-b dark:border-gray-700">
            <td class="py-4 px-6"><?php echo $i; ?></td>
            <td class="py-4 px-6">John Doe</td>
            <td class="py-4 px-6">Account Verification Issue</td>
            <td class="py-4 px-6">2025-04-25 10:24 AM</td>
            <td class="py-4 px-6">
              <a href="view-message.php?id=<?php echo $i; ?>" class="text-blue-600 hover:underline text-sm">View</a>
            </td>
          </tr>
          <?php endfor; ?>
        </tbody>
      </table>
    </div>
  </div>

</main>
</div>

<!-- JavaScript -->
<script>
// Preloader (optional if needed)

// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const htmlEl = document.documentElement;

if (localStorage.getItem('theme') === 'dark') {
  htmlEl.classList.add('dark');
  themeIcon.className = 'bx bx-sun';
} else {
  htmlEl.classList.remove('dark');
  themeIcon.className = 'bx bx-moon';
}

themeToggle.addEventListener('click', () => {
  htmlEl.classList.toggle('dark');
  if (htmlEl.classList.contains('dark')) {
    themeIcon.className = 'bx bx-sun';
    localStorage.setItem('theme', 'dark');
  } else {
    themeIcon.className = 'bx bx-moon';
    localStorage.setItem('theme', 'light');
  }
});

// Sidebar Toggle
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.getElementById('sidebar');
sidebarToggle?.addEventListener('click', () => {
  sidebar.classList.toggle('sidebar-collapsed');
});

// Mobile Sidebar
const mobileSidebarButton = document.getElementById('mobileSidebarButton');
mobileSidebarButton?.addEventListener('click', () => {
  sidebar.classList.toggle('sidebar-collapsed');
});

// Dropdowns
document.querySelectorAll('#usersDropdown, #settingsDropdown').forEach(drop => {
  const link = drop.querySelector('a');
  const submenu = drop.querySelector('div');
  link.addEventListener('click', e => {
    e.preventDefault();
    submenu.classList.toggle('hidden');
  });
});

// Profile Dropdown
const profileButton = document.getElementById('profileButton');
const profileDropdown = document.getElementById('profileDropdown');
profileButton?.addEventListener('click', (e) => {
  e.stopPropagation();
  profileDropdown.classList.toggle('hidden');
});
document.addEventListener('click', (e) => {
  if (!profileButton.contains(e.target)) {
    profileDropdown.classList.add('hidden');
  }
});

// Notification Dot
const notificationButton = document.getElementById('notificationButton');
const notificationDot = document.getElementById('notificationDot');
notificationButton?.addEventListener('click', () => {
  notificationDot.style.display = 'none';
});
</script>

</body>
</html>