<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Payment Gateways</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 overflow-x-auto">
      <table class="w-full table-auto">
        <thead>
          <tr class="bg-gray-100 dark:bg-gray-700">
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Gateway</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Status</th>
            <th class="px-6 py-3 text-right text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr class="border-b dark:border-gray-700">
            <td class="px-6 py-4 text-gray-800 dark:text-gray-300">PayPal</td>
            <td class="px-6 py-4 text-green-600">Active</td>
            <td class="px-6 py-4 text-right">
              <button class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm">Edit</button>
            </td>
          </tr>
          <tr class="border-b dark:border-gray-700">
            <td class="px-6 py-4 text-gray-800 dark:text-gray-300">Stripe</td>
            <td class="px-6 py-4 text-red-600">Inactive</td>
            <td class="px-6 py-4 text-right">
              <button class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm">Edit</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>