<?php
// profile.php
?>

<!-- Head -->
<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="flex-1 flex flex-col min-h-screen">

  <!-- Topbar -->
  <?php include('topbar.php'); ?>

  <!-- Profile Content -->
  <main class="flex-1 p-6">
    <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-6">My Profile</h1>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
      
      <!-- Profile Card -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 flex flex-col items-center">
        <img src="https://i.pravatar.cc/100" alt="Profile Picture" class="rounded-full w-24 h-24 mb-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-2">Admin Name</h2>
        <p class="text-gray-600 dark:text-gray-300">Administrator</p>
        <button class="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Change Picture</button>
      </div>

      <!-- Profile Information Form -->
      <div class="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">Personal Information</h2>
        
        <form class="space-y-6">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label class="block text-gray-700 dark:text-gray-300 mb-2">Full Name</label>
              <input type="text" value="Admin Name" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
            </div>

            <div>
              <label class="block text-gray-700 dark:text-gray-300 mb-2">Email</label>
              <input type="email" value="admin@example.com" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
            </div>

            <div>
              <label class="block text-gray-700 dark:text-gray-300 mb-2">Phone</label>
              <input type="text" value="+1234567890" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
            </div>

            <div>
              <label class="block text-gray-700 dark:text-gray-300 mb-2">Role</label>
              <input type="text" value="Administrator" disabled class="w-full px-4 py-2 rounded border bg-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
            </div>
          </div>

          <div class="flex justify-end">
            <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Save Changes</button>
          </div>
        </form>
      </div>

    </div>

    <!-- Change Password Section -->
    <div class="mt-10 bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">Change Password</h2>

      <form class="space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Current Password</label>
            <input type="password" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
          </div>

          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">New Password</label>
            <input type="password" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
          </div>

          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Confirm New Password</label>
            <input type="password" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
          </div>
        </div>

        <div class="flex justify-end">
          <button type="submit" class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">Update Password</button>
        </div>
      </form>
    </div>

  </main>
</div>

<!-- JavaScript -->
<script>
// Preloader (optional if needed)

// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const htmlEl = document.documentElement;

if (localStorage.getItem('theme') === 'dark') {
  htmlEl.classList.add('dark');
  themeIcon.className = 'bx bx-sun';
} else {
  htmlEl.classList.remove('dark');
  themeIcon.className = 'bx bx-moon';
}

themeToggle.addEventListener('click', () => {
  htmlEl.classList.toggle('dark');
  if (htmlEl.classList.contains('dark')) {
    themeIcon.className = 'bx bx-sun';
    localStorage.setItem('theme', 'dark');
  } else {
    themeIcon.className = 'bx bx-moon';
    localStorage.setItem('theme', 'light');
  }
});

// Sidebar Toggle
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.getElementById('sidebar');
sidebarToggle?.addEventListener('click', () => {
  sidebar.classList.toggle('sidebar-collapsed');
});

// Mobile Sidebar
const mobileSidebarButton = document.getElementById('mobileSidebarButton');
mobileSidebarButton?.addEventListener('click', () => {
  sidebar.classList.toggle('sidebar-collapsed');
});

// Dropdowns
document.querySelectorAll('#usersDropdown, #settingsDropdown').forEach(drop => {
  const link = drop.querySelector('a');
  const submenu = drop.querySelector('div');
  link.addEventListener('click', e => {
    e.preventDefault();
    submenu.classList.toggle('hidden');
  });
});

// Profile Dropdown
const profileButton = document.getElementById('profileButton');
const profileDropdown = document.getElementById('profileDropdown');
profileButton?.addEventListener('click', (e) => {
  e.stopPropagation();
  profileDropdown.classList.toggle('hidden');
});
document.addEventListener('click', (e) => {
  if (!profileButton.contains(e.target)) {
    profileDropdown.classList.add('hidden');
  }
});

// Notification Dot
const notificationButton = document.getElementById('notificationButton');
const notificationDot = document.getElementById('notificationDot');
notificationButton?.addEventListener('click', () => {
  notificationDot.style.display = 'none';
});
</script>

</body>
</html>