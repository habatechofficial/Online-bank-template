<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">User Reports</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 overflow-x-auto">
      <table class="min-w-full text-left">
        <thead>
          <tr class="bg-gray-100 dark:bg-gray-700">
            <th class="py-2 px-4">User</th>
            <th class="py-2 px-4">Email</th>
            <th class="py-2 px-4">Status</th>
            <th class="py-2 px-4">Registered</th>
          </tr>
        </thead>
        <tbody>
          <tr class="border-b dark:border-gray-700">
            <td class="py-2 px-4">John Doe</td>
            <td class="py-2 px-4">john@example.com</td>
            <td class="py-2 px-4">Active</td>
            <td class="py-2 px-4">2025-01-12</td>
          </tr>
          <tr>
            <td class="py-2 px-4">Jane Smith</td>
            <td class="py-2 px-4">jane@example.com</td>
            <td class="py-2 px-4">Inactive</td>
            <td class="py-2 px-4">2025-02-20</td>
          </tr>
        </tbody>
      </table>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>
</body>
</html>