<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 flex items-center justify-center min-h-screen">
  <div class="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg w-full max-w-md">
    <h2 class="text-2xl font-bold text-center mb-6 text-gray-800 dark:text-white">Forgot Password</h2>

    <form action="reset-password.php" method="POST" class="space-y-4">
      <div>
        <label class="block text-gray-700 dark:text-gray-300 mb-1">Enter your email</label>
        <input type="email" name="email" class="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white" required>
      </div>

      <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded">Send Reset Link</button>
    </form>
  </div>

<?php include('scripts.php'); ?>
</body>
</html>