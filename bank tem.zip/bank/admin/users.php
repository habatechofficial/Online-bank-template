<?php
// users.php
?>

<!-- Head -->
<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="flex-1 flex flex-col min-h-screen">

  <!-- Topbar -->
  <?php include('topbar.php'); ?>

  <!-- Users List -->
  <main class="flex-1 p-6">
    <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-6">All Users</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div class="overflow-x-auto">
        <table class="min-w-full table-auto">
          <thead>
            <tr class="text-gray-700 dark:text-gray-300 text-left">
              <th class="py-3 px-6">#</th>
              <th class="py-3 px-6">Name</th>
              <th class="py-3 px-6">Email</th>
              <th class="py-3 px-6">Phone</th>
              <th class="py-3 px-6">Status</th>
              <th class="py-3 px-6">Action</th>
            </tr>
          </thead>
          <tbody class="text-gray-600 dark:text-gray-400">
            <?php for($i=1;$i<=5;$i++): ?>
            <tr class="border-b dark:border-gray-700">
              <td class="py-4 px-6"><?php echo $i; ?></td>
              <td class="py-4 px-6">John Doe <?php echo $i; ?></td>
              <td class="py-4 px-6">johndoe<?php echo $i; ?>@example.com</td>
              <td class="py-4 px-6">+12345678<?php echo $i; ?></td>
              <td class="py-4 px-6">
                <span class="inline-block px-2 py-1 text-sm bg-green-100 text-green-600 rounded-full">Active</span>
              </td>
              <td class="py-4 px-6">
                <a href="user-details.php?id=<?php echo $i; ?>" class="text-blue-600 hover:underline text-sm">View</a>
              </td>
            </tr>
            <?php endfor; ?>
          </tbody>
        </table>
      </div>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>


</body>
</html>