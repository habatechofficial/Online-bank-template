<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Audit Logs</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 overflow-x-auto">
      <table class="min-w-full text-left">
        <thead>
          <tr class="bg-gray-100 dark:bg-gray-700">
            <th class="py-2 px-4">Date</th>
            <th class="py-2 px-4">User</th>
            <th class="py-2 px-4">Action</th>
            <th class="py-2 px-4">IP Address</th>
          </tr>
        </thead>
        <tbody>
          <tr class="border-t dark:border-gray-700">
            <td class="py-2 px-4">2025-04-25</td>
            <td class="py-2 px-4">Admin</td>
            <td class="py-2 px-4">Edited User Profile</td>
            <td class="py-2 px-4">192.168.1.100</td>
          </tr>
          <tr class="border-t dark:border-gray-700">
            <td class="py-2 px-4">2025-04-24</td>
            <td class="py-2 px-4">Manager</td>
            <td class="py-2 px-4">Approved Loan</td>
            <td class="py-2 px-4">192.168.1.101</td>
          </tr>
        </tbody>
      </table>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>
</body>
</html>