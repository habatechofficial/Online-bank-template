<!-- Sidebar -->
<aside id="sidebar" class="w-64 bg-white dark:bg-gray-800 shadow-md min-h-screen transition-transform">
  <div class="p-6">
    <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-6">RamzBank</h1>

    <!-- Menu Start -->
    <nav class="space-y-4">

      <!-- User Management -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('userManagementMenu')">
          User Management
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="userManagementMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="users.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Users</a>
          <a href="user-details.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">User Details</a>
          <a href="add-user.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Add User</a>
          <a href="kyc-management.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">KYC Management</a>
          <a href="user-accounts.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">User Accounts</a>
        </div>
      </div>

      <!-- Banking Operations -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('bankingOperationsMenu')">
          Banking Operations
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="bankingOperationsMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="accounts.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Accounts</a>
          <a href="add-account.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Add Account</a>
          <a href="transactions.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Transactions</a>
          <a href="deposits.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Deposits</a>
          <a href="withdrawals.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Withdrawals</a>
          <a href="transfers.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Transfers</a>
          <a href="cards.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Cards</a>
          <a href="loans.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Loans</a>
        </div>
      </div>

      <!-- Financial Products -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('financialProductsMenu')">
          Financial Products
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="financialProductsMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="loan-applications.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Loan Applications</a>
          <a href="credit-cards.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Credit Cards</a>
          <a href="investment-plans.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Investment Plans</a>
          <a href="savings-plans.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Savings Plans</a>
        </div>
      </div>

      <!-- Site Management -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('siteManagementMenu')">
          Site Management
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="siteManagementMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="settings.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Settings</a>
          <a href="system-settings.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">System Settings</a>
          <a href="payment-gateways.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Payment Gateways</a>
          <a href="email-templates.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Email Templates</a>
          <a href="sms-templates.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">SMS Templates</a>
          <a href="cms-pages.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">CMS Pages</a>
          <a href="banners.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Banners</a>
        </div>
      </div>

      <!-- Admin Management -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('adminManagementMenu')">
          Admin Management
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="adminManagementMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="admins.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Admins</a>
          <a href="add-admin.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Add Admin</a>
          <a href="roles-permissions.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Roles & Permissions</a>
          <a href="activity-logs.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Activity Logs</a>
        </div>
      </div>

      <!-- Support System -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('supportSystemMenu')">
          Support System
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="supportSystemMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="support-tickets.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Support Tickets</a>
          <a href="view-ticket.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">View Ticket</a>
          <a href="faq-management.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">FAQ Management</a>
        </div>
      </div>

      <!-- Reports & Logs -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('reportsLogsMenu')">
          Reports & Logs
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="reportsLogsMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="financial-reports.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Financial Reports</a>
          <a href="user-reports.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">User Reports</a>
          <a href="transaction-reports.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Transaction Reports</a>
          <a href="loan-reports.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Loan Reports</a>
          <a href="audit-logs.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Audit Logs</a>
        </div>
      </div>

      <!-- Authentication/Security -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('authSecurityMenu')">
          Authentication / Security
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="authSecurityMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="login.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Login</a>
          <a href="forgot-password.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Forgot Password</a>
          <a href="reset-password.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Reset Password</a>
          <a href="lock-screen.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Lock Screen</a>
          <a href="2fa-settings.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">2FA Settings</a>
        </div>
      </div>

      <!-- Optional Tools -->
      <div>
        <button class="w-full flex justify-between items-center text-left text-gray-700 dark:text-gray-200 font-semibold py-2" onclick="toggleMenu('optionalToolsMenu')">
          Optional Tools
          <i class="bx bx-chevron-down"></i>
        </button>
        <div id="optionalToolsMenu" class="ml-4 mt-2 space-y-2 hidden">
          <a href="maintenance-mode.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Maintenance Mode</a>
          <a href="api-management.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">API Management</a>
          <a href="currency-exchange.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Currency Exchange</a>
          <a href="custom-notifications.php" class="block text-gray-600 dark:text-gray-400 hover:text-blue-500">Custom Notifications</a>
        </div>
      </div>

    </nav>
    <!-- Menu End -->
  </div>
</aside>