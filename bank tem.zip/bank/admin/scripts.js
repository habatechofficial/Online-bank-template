
// Preloader (optional if needed)

// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const htmlEl = document.documentElement;

if (localStorage.getItem('theme') === 'dark') {
  htmlEl.classList.add('dark');
  themeIcon.className = 'bx bx-sun';
} else {
  htmlEl.classList.remove('dark');
  themeIcon.className = 'bx bx-moon';
}

themeToggle.addEventListener('click', () => {
  htmlEl.classList.toggle('dark');
  if (htmlEl.classList.contains('dark')) {
    themeIcon.className = 'bx bx-sun';
    localStorage.setItem('theme', 'dark');
  } else {
    themeIcon.className = 'bx bx-moon';
    localStorage.setItem('theme', 'light');
  }
});

// Sidebar Toggle
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.getElementById('sidebar');
sidebarToggle?.addEventListener('click', () => {
  sidebar.classList.toggle('sidebar-collapsed');
});

// Mobile Sidebar
const mobileSidebarButton = document.getElementById('mobileSidebarButton');
mobileSidebarButton?.addEventListener('click', () => {
  sidebar.classList.toggle('sidebar-collapsed');
});

// Dropdowns
document.querySelectorAll('#usersDropdown, #settingsDropdown').forEach(drop => {
  const link = drop.querySelector('a');
  const submenu = drop.querySelector('div');
  link.addEventListener('click', e => {
    e.preventDefault();
    submenu.classList.toggle('hidden');
  });
});

// Profile Dropdown
const profileButton = document.getElementById('profileButton');
const profileDropdown = document.getElementById('profileDropdown');
profileButton?.addEventListener('click', (e) => {
  e.stopPropagation();
  profileDropdown.classList.toggle('hidden');
});
document.addEventListener('click', (e) => {
  if (!profileButton.contains(e.target)) {
    profileDropdown.classList.add('hidden');
  }
});

// Notification Dot
const notificationButton = document.getElementById('notificationButton');
const notificationDot = document.getElementById('notificationDot');
notificationButton?.addEventListener('click', () => {
  notificationDot.style.display = 'none';
});
