<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <div class="mb-6">
      <h1 class="text-3xl font-bold text-gray-800 dark:text-white">View Ticket</h1>
      <p class="text-gray-500 dark:text-gray-400 mt-1">Ticket #12345: Unable to Login</p>
    </div>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 space-y-6">

      <div>
        <p class="text-gray-700 dark:text-gray-300">User Message:</p>
        <p class="mt-2 dark:text-white">I am unable to login to my account after resetting the password.</p>
      </div>

      <div>
        <label class="block mb-2 text-gray-700 dark:text-gray-300">Reply</label>
        <textarea class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" rows="4" placeholder="Write your reply..."></textarea>
      </div>

      <div class="flex justify-end">
        <button class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">Send Reply</button>
      </div>

    </div>

  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>