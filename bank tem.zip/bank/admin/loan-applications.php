<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Loan Applications</h1>

    <!-- Search + Filter -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6 space-y-4 md:space-y-0">
      <div>
        <input type="text" placeholder="Search by Name or Email" class="px-4 py-2 w-full md:w-64 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
      </div>
      <div>
        <select class="px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white">
          <option>Status Filter</option>
          <option>Pending</option>
          <option>Approved</option>
          <option>Rejected</option>
        </select>
      </div>
    </div>

    <!-- Applications Table -->
    <div class="overflow-x-auto">
      <table class="min-w-full bg-white dark:bg-gray-800 rounded-lg overflow-hidden">
        <thead class="bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-sm">
          <tr>
            <th class="py-3 px-6 text-left">Applicant</th>
            <th class="py-3 px-6 text-left">Email</th>
            <th class="py-3 px-6 text-left">Amount</th>
            <th class="py-3 px-6 text-left">Status</th>
            <th class="py-3 px-6 text-center">Actions</th>
          </tr>
        </thead>
        <tbody class="text-gray-700 dark:text-gray-300 text-sm">
          <tr class="border-b dark:border-gray-700">
            <td class="py-4 px-6">John Doe</td>
            <td class="py-4 px-6">john@example.com</td>
            <td class="py-4 px-6">$5,000</td>
            <td class="py-4 px-6">
              <span class="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-xs">Pending</span>
            </td>
            <td class="py-4 px-6 text-center space-x-2">
            <button class="viewButton bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-xs">
  View
</button>
              <button class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-xs">Approve</button>
              <button class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-xs">Reject</button>
            </td>
          </tr>
          <!-- Repeat <tr> for more applications -->
        </tbody>
      </table>
    </div>

  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>