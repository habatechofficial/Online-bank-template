<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Custom Notifications</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <form class="space-y-6">
        <div>
          <label class="block text-gray-700 dark:text-gray-300 mb-1">Notification Title</label>
          <input type="text" class="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white" placeholder="Title">
        </div>

        <div>
          <label class="block text-gray-700 dark:text-gray-300 mb-1">Message</label>
          <textarea class="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white" rows="4" placeholder="Your message..."></textarea>
        </div>

        <div class="flex justify-end">
          <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded">Send Notification</button>
        </div>
      </form>
    </div>
  </main>
</div>

<?php include('scripts.php'); ?>
</body>
</html>