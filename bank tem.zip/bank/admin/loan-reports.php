<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Loan Reports</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 overflow-x-auto">
      <table class="min-w-full text-left">
        <thead>
          <tr class="bg-gray-100 dark:bg-gray-700">
            <th class="py-2 px-4">Applicant</th>
            <th class="py-2 px-4">Loan Type</th>
            <th class="py-2 px-4">Amount</th>
            <th class="py-2 px-4">Status</th>
          </tr>
        </thead>
        <tbody>
          <tr class="border-t dark:border-gray-700">
            <td class="py-2 px-4">Alice Brown</td>
            <td class="py-2 px-4">Home Loan</td>
            <td class="py-2 px-4">$250,000</td>
            <td class="py-2 px-4 text-yellow-500">Pending</td>
          </tr>
          <tr class="border-t dark:border-gray-700">
            <td class="py-2 px-4">Bob Martin</td>
            <td class="py-2 px-4">Car Loan</td>
            <td class="py-2 px-4">$25,000</td>
            <td class="py-2 px-4 text-green-500">Approved</td>
          </tr>
        </tbody>
      </table>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>
</body>
</html>