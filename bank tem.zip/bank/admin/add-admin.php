<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Add New Admin</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <form class="space-y-6">

        <div>
          <label class="block mb-2 text-gray-700 dark:text-gray-300">Full Name</label>
          <input type="text" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" placeholder="John Doe">
        </div>

        <div>
          <label class="block mb-2 text-gray-700 dark:text-gray-300">Email Address</label>
          <input type="email" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" placeholder="admin@example.com">
        </div>

        <div>
          <label class="block mb-2 text-gray-700 dark:text-gray-300">Password</label>
          <input type="password" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white">
        </div>

        <div>
          <label class="block mb-2 text-gray-700 dark:text-gray-300">Role</label>
          <select class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white">
            <option>Super Admin</option>
            <option>Support</option>
          </select>
        </div>

        <div class="flex justify-end">
          <button type="submit" class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">Add Admin</button>
        </div>

      </form>
    </div>

  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>