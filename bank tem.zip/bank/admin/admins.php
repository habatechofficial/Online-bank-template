<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-3xl font-bold text-gray-800 dark:text-white">Admins</h1>
      <a href="add-admin.php" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Add New Admin</a>
    </div>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 overflow-x-auto">
      <table class="w-full table-auto">
        <thead>
          <tr class="bg-gray-100 dark:bg-gray-700">
            <th class="px-6 py-3 text-left text-xs font-medium uppercase">Name</th>
            <th class="px-6 py-3 text-left text-xs font-medium uppercase">Email</th>
            <th class="px-6 py-3 text-left text-xs font-medium uppercase">Role</th>
            <th class="px-6 py-3 text-right text-xs font-medium uppercase">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr class="border-b dark:border-gray-700">
            <td class="px-6 py-4">John Doe</td>
            <td class="px-6 py-4">john@example.com</td>
            <td class="px-6 py-4">Super Admin</td>
            <td class="px-6 py-4 text-right">
              <button class="px-3 py-1 bg-blue-500 text-white rounded text-sm">Edit</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>