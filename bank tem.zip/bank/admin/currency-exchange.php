<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Currency Exchange Rates</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <table class="min-w-full table-auto">
        <thead class="bg-gray-200 dark:bg-gray-700">
          <tr>
            <th class="px-4 py-2 text-gray-700 dark:text-gray-300">Currency</th>
            <th class="px-4 py-2 text-gray-700 dark:text-gray-300">Rate</th>
            <th class="px-4 py-2 text-gray-700 dark:text-gray-300">Updated At</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800">
          <tr class="border-t dark:border-gray-700">
            <td class="px-4 py-2">USD</td>
            <td class="px-4 py-2">1.00</td>
            <td class="px-4 py-2">2025-04-26</td>
          </tr>
          <tr class="border-t dark:border-gray-700">
            <td class="px-4 py-2">EUR</td>
            <td class="px-4 py-2">0.91</td>
            <td class="px-4 py-2">2025-04-26</td>
          </tr>
          <tr class="border-t dark:border-gray-700">
            <td class="px-4 py-2">JPY</td>
            <td class="px-4 py-2">134.50</td>
            <td class="px-4 py-2">2025-04-26</td>
          </tr>
        </tbody>
      </table>
    </div>
  </main>
</div>

<?php include('scripts.php'); ?>
</body>
</html>