<?php
// user-details.php
?>

<!-- Head -->
<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="flex-1 flex flex-col min-h-screen">

  <!-- Topbar -->
  <?php include('topbar.php'); ?>

  <!-- User Details -->
  <main class="flex-1 p-6">
    <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-6">User Details</h1>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
      
      <!-- Profile Card -->
      <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 flex flex-col items-center">
        <img src="https://i.pravatar.cc/100?img=<?php echo rand(1, 70); ?>" alt="Profile Picture" class="rounded-full w-24 h-24 mb-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-2">John Doe</h2>
        <p class="text-gray-600 dark:text-gray-300">Customer</p>
        <span class="mt-2 inline-block px-3 py-1 text-sm bg-green-100 text-green-600 rounded-full">Active</span>
      </div>

      <!-- User Information -->
      <div class="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow p-6">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">Personal Information</h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Full Name</label>
            <input type="text" value="John Doe" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" readonly />
          </div>

          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Email</label>
            <input type="email" value="johndoe@example.com" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" readonly />
          </div>

          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Phone</label>
            <input type="text" value="+1234567890" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" readonly />
          </div>

          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Account Balance</label>
            <input type="text" value="$12,000" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" readonly />
          </div>
        </div>

        <div class="flex space-x-4">
          <button class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Edit User</button>
          <button class="px-6 py-2 bg-red-600 text-white rounded hover:bg-red-700">Suspend Account</button>
        </div>

      </div>

    </div>

    <!-- Transactions Section -->
    <div class="mt-10 bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">Recent Transactions</h2>

      <div class="overflow-x-auto">
        <table class="min-w-full table-auto">
          <thead>
            <tr class="text-gray-700 dark:text-gray-300 text-left">
              <th class="py-3 px-6">Date</th>
              <th class="py-3 px-6">Type</th>
              <th class="py-3 px-6">Amount</th>
              <th class="py-3 px-6">Status</th>
            </tr>
          </thead>
          <tbody class="text-gray-600 dark:text-gray-400">
            <?php for($i=1;$i<=5;$i++): ?>
            <tr class="border-b dark:border-gray-700">
              <td class="py-4 px-6">2025-04-<?php echo 20+$i; ?></td>
              <td class="py-4 px-6">Deposit</td>
              <td class="py-4 px-6">$<?php echo 1000*$i; ?></td>
              <td class="py-4 px-6">
                <span class="inline-block px-2 py-1 text-sm bg-green-100 text-green-600 rounded-full">Completed</span>
              </td>
            </tr>
            <?php endfor; ?>
          </tbody>
        </table>
      </div>

    </div>

  </main>

</div>

<?php include('scripts.php'); ?>

</body>
</html>