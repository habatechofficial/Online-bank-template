<!-- Modal Background -->
<div id="viewModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
  <!-- Modal Content -->
  <div class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-xl font-bold text-gray-800 dark:text-white">Details</h2>
      <button id="closeModal" class="text-gray-500 hover:text-gray-800 dark:hover:text-gray-300">&times;</button>
    </div>
    
    <div id="modalContent" class="space-y-4 text-gray-700 dark:text-gray-300">
      <!-- Dynamic content will be inserted here -->
      <p><strong>Name:</strong> Jane Smith</p>
      <p><strong>Type:</strong> Loan Application</p>
      <p><strong>Status:</strong> Pending</p>
    </div>

    <div class="mt-6 text-right">
      <button id="closeModalBtn" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">Close</button>
    </div>
  </div>
</div>


<script>
// Preloader (optional if needed)

// Modal Handling
const viewModal = document.getElementById('viewModal');
const closeModal = document.getElementById('closeModal');
const closeModalBtn = document.getElementById('closeModalBtn');

// Open modal when clicking any "View" button
document.querySelectorAll('.viewButton').forEach(button => {
  button.addEventListener('click', () => {
    // Optional: Update modal content dynamically here
    viewModal.classList.remove('hidden');
  });
});

// Close modal
closeModal?.addEventListener('click', () => viewModal.classList.add('hidden'));
closeModalBtn?.addEventListener('click', () => viewModal.classList.add('hidden'));
viewModal?.addEventListener('click', (e) => {
  if (e.target === viewModal) viewModal.classList.add('hidden');
});

// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const htmlEl = document.documentElement;

if (localStorage.getItem('theme') === 'dark') {
  htmlEl.classList.add('dark');
  if (themeIcon) themeIcon.className = 'bx bx-sun';
} else {
  htmlEl.classList.remove('dark');
  if (themeIcon) themeIcon.className = 'bx bx-moon';
}

themeToggle?.addEventListener('click', () => {
  htmlEl.classList.toggle('dark');
  if (htmlEl.classList.contains('dark')) {
    if (themeIcon) themeIcon.className = 'bx bx-sun';
    localStorage.setItem('theme', 'dark');
  } else {
    if (themeIcon) themeIcon.className = 'bx bx-moon';
    localStorage.setItem('theme', 'light');
  }
});

// Sidebar Toggle (Desktop)
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.getElementById('sidebar');
sidebarToggle?.addEventListener('click', () => {
  sidebar?.classList.toggle('sidebar-collapsed');
});

// Sidebar Toggle (Mobile)
const mobileSidebarButton = document.getElementById('mobileSidebarButton');
mobileSidebarButton?.addEventListener('click', () => {
  sidebar?.classList.toggle('sidebar-collapsed');
});

// Profile Dropdown
const profileButton = document.getElementById('profileButton');
const profileDropdown = document.getElementById('profileDropdown');
profileButton?.addEventListener('click', (e) => {
  e.stopPropagation();
  profileDropdown?.classList.toggle('hidden');
});
document.addEventListener('click', (e) => {
  if (!profileButton?.contains(e.target)) {
    profileDropdown?.classList.add('hidden');
  }
});

// Notification Dot
const notificationButton = document.getElementById('notificationButton');
const notificationDot = document.getElementById('notificationDot');
notificationButton?.addEventListener('click', () => {
  if (notificationDot) notificationDot.style.display = 'none';
});

// Sidebar Menu Dropdowns
function toggleMenu(menuId) {
  const menu = document.getElementById(menuId);
  menu?.classList.toggle('hidden');
}

// (Optional) Auto-close other menus when one opens (Accordion behavior)

function toggleMenu(menuId) {
  document.querySelectorAll('aside nav div > div').forEach(menu => {
    if (menu.id !== menuId) {
      menu.classList.add('hidden');
    }
  });
  const targetMenu = document.getElementById(menuId);
  targetMenu?.classList.toggle('hidden');
}


</script>