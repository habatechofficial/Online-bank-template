<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Maintenance Mode</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 space-y-6">
      <p class="text-gray-700 dark:text-gray-300">Enable or disable maintenance mode for your platform. Users will see a maintenance message when trying to access the system.</p>

      <div class="flex items-center space-x-4">
        <label class="text-gray-800 dark:text-white">Maintenance Mode:</label>
        <button id="toggleMaintenance" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded">Activate</button>
      </div>

      <div id="statusMessage" class="text-green-500 dark:text-green-400 mt-4 hidden">Maintenance Mode is Active!</div>
    </div>
  </main>
</div>

<script>
const toggleMaintenance = document.getElementById('toggleMaintenance');
const statusMessage = document.getElementById('statusMessage');

toggleMaintenance.addEventListener('click', () => {
  statusMessage.classList.toggle('hidden');
  toggleMaintenance.textContent = statusMessage.classList.contains('hidden') ? 'Activate' : 'Deactivate';
});
</script>

<?php include('scripts.php'); ?>
</body>
</html>