<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Support Tickets</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 overflow-x-auto">
      <table class="w-full table-auto">
        <thead>
          <tr class="bg-gray-100 dark:bg-gray-700">
            <th class="px-6 py-3 text-left text-xs font-medium uppercase">Ticket ID</th>
            <th class="px-6 py-3 text-left text-xs font-medium uppercase">Subject</th>
            <th class="px-6 py-3 text-left text-xs font-medium uppercase">Status</th>
            <th class="px-6 py-3 text-right text-xs font-medium uppercase">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr class="border-b dark:border-gray-700">
            <td class="px-6 py-4">#12345</td>
            <td class="px-6 py-4">Unable to Login</td>
            <td class="px-6 py-4 text-yellow-600">Open</td>
            <td class="px-6 py-4 text-right">
              <a href="view-ticket.php" class="px-3 py-1 bg-blue-500 text-white rounded text-sm">View</a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>