<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Add New Account</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <form class="space-y-6">
        <div>
          <label class="block text-gray-700 dark:text-gray-300 mb-2">Account Holder</label>
          <input type="text" class="w-full px-4 py-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white">
        </div>
        <div>
          <label class="block text-gray-700 dark:text-gray-300 mb-2">Account Type</label>
          <select class="w-full px-4 py-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white">
            <option>Checking</option>
            <option>Savings</option>
            <option>Loan</option>
          </select>
        </div>
        <div class="flex justify-end">
          <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Create Account</button>
        </div>
      </form>
    </div>
  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>