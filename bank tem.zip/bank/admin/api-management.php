<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">API Management</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div class="mb-4">
        <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">Generate New API Key</button>
      </div>

      <table class="min-w-full table-auto">
        <thead class="bg-gray-200 dark:bg-gray-700">
          <tr>
            <th class="px-4 py-2 text-gray-700 dark:text-gray-300">API Key</th>
            <th class="px-4 py-2 text-gray-700 dark:text-gray-300">Status</th>
            <th class="px-4 py-2 text-gray-700 dark:text-gray-300">Actions</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800">
          <tr class="border-t dark:border-gray-700">
            <td class="px-4 py-2">abcdef123456</td>
            <td class="px-4 py-2"><span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Active</span></td>
            <td class="px-4 py-2">
              <button class="text-red-500 hover:underline text-sm">Revoke</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </main>
</div>

<?php include('scripts.php'); ?>
</body>
</html>