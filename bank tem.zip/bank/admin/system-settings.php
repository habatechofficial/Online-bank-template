<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">System Settings</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6 space-y-6">
      
      <div>
        <label class="block mb-2 text-gray-700 dark:text-gray-300">Timezone</label>
        <select class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white">
          <option>UTC</option>
          <option selected>GMT</option>
          <option>EST</option>
          <option>PST</option>
        </select>
      </div>

      <div>
        <label class="block mb-2 text-gray-700 dark:text-gray-300">Currency</label>
        <input type="text" class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" value="USD">
      </div>

      <div class="flex justify-end">
        <button type="submit" class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">Update Settings</button>
      </div>

    </div>

  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>