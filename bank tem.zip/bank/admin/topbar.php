<!-- topbar.php -->
<header class="flex items-center justify-between bg-white dark:bg-gray-800 shadow px-6 py-4">

  <div class="flex items-center gap-4">
    <button id="mobileSidebarButton" class="text-2xl text-gray-600 dark:text-gray-300 focus:outline-none lg:hidden">
      <i class='bx bx-menu'></i>
    </button>
    <button id="themeToggle" class="text-2xl text-gray-600 dark:text-gray-300 focus:outline-none">
      <i id="themeIcon" class='bx bx-moon'></i>
    </button>
  </div>

  <div class="flex items-center gap-6 relative">
    
    <!-- Notification Button -->
    <button id="notificationButton" class="relative text-2xl text-gray-600 dark:text-gray-300 focus:outline-none">
      <i class='bx bx-bell'></i>
      <span id="notificationDot" class="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
    </button>

    <!-- Profile Dropdown -->
    <div class="relative">
      <button id="profileButton" class="flex items-center space-x-3 focus:outline-none">
        <img src="https://i.pravatar.cc/40" alt="Profile" class="rounded-full w-10 h-10">
        <i class='bx bx-chevron-down text-2xl text-gray-600 dark:text-gray-300'></i>
      </button>

      <div id="profileDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white dark:bg-gray-700 rounded-md shadow-lg py-2 z-50">
        <a href="profile.php" class="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">Profile</a>
        <a href="site-settings.php" class="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">Settings</a>
        <div class="border-t dark:border-gray-600"></div>
        <a href="logout.php" class="block px-4 py-2 text-red-600 hover:bg-gray-100 dark:hover:bg-gray-600">Logout</a>
      </div>
    </div>

  </div>

</header>