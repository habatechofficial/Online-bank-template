<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 flex items-center justify-center min-h-screen">
  <div class="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg w-full max-w-sm text-center">
    <img src="assets/user-avatar.png" alt="User" class="w-24 h-24 mx-auto rounded-full mb-4">
    <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-2">John Doe</h2>
    <p class="text-gray-600 dark:text-gray-400 mb-6">Screen Locked</p>

    <form action="dashboard.php" method="POST" class="space-y-4">
      <div>
        <input type="password" name="password" placeholder="Enter password" class="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white" required>
      </div>

      <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded">Unlock</button>
    </form>

    <div class="mt-4">
      <a href="login.php" class="text-sm text-blue-500 hover:underline">Not John Doe?</a>
    </div>
  </div>

<?php include('scripts.php'); ?>
</body>
</html>