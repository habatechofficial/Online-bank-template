<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Transaction Reports</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <canvas id="transactionChart" height="100"></canvas>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx2 = document.getElementById('transactionChart').getContext('2d');
const transactionChart = new Chart(ctx2, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
        datasets: [{
            label: 'Transactions',
            data: [50, 75, 65, 90, 100],
            borderColor: 'rgba(16, 185, 129, 0.8)',
            backgroundColor: 'rgba(16, 185, 129, 0.3)',
            fill: true,
            tension: 0.4,
        }]
    },
    options: {
        responsive: true
    }
});
</script>

</body>
</html>