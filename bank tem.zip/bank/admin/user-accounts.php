<?php
// user-accounts.php
?>

<!-- Head -->
<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="flex-1 flex flex-col min-h-screen">

  <!-- Topbar -->
  <?php include('topbar.php'); ?>

  <!-- User Bank Accounts -->
  <main class="flex-1 p-6">
    <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-6">User Accounts</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div class="overflow-x-auto">
        <table class="min-w-full table-auto">
          <thead>
            <tr class="text-gray-700 dark:text-gray-300 text-left">
              <th class="py-3 px-6">#</th>
              <th class="py-3 px-6">Account Holder</th>
              <th class="py-3 px-6">Account Number</th>
              <th class="py-3 px-6">Account Type</th>
              <th class="py-3 px-6">Balance</th>
              <th class="py-3 px-6">Action</th>
            </tr>
          </thead>
          <tbody class="text-gray-600 dark:text-gray-400">
            <?php for($i=1;$i<=5;$i++): ?>
            <tr class="border-b dark:border-gray-700">
              <td class="py-4 px-6"><?php echo $i; ?></td>
              <td class="py-4 px-6">Jane Smith <?php echo $i; ?></td>
              <td class="py-4 px-6">ACC12345<?php echo $i; ?></td>
              <td class="py-4 px-6">Savings</td>
              <td class="py-4 px-6">$<?php echo 2000*$i; ?></td>
              <td class="py-4 px-6">
                <a href="user-details.php?id=<?php echo $i; ?>" class="text-blue-600 hover:underline text-sm">View</a>
              </td>
            </tr>
            <?php endfor; ?>
          </tbody>
        </table>
      </div>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>

</body>
</html>