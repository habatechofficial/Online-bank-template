<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col min-h-screen">

  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Banners Management</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">

      <div class="flex justify-end mb-4">
        <button class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Upload Banner</button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden">
          <img src="https://via.placeholder.com/600x300" alt="Banner" class="w-full">
        </div>
      </div>

    </div>

  </main>

</div>

<?php include('scripts.php'); ?>
</body>
</html>