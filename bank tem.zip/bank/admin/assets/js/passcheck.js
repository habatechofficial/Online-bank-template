document.getElementById('password').addEventListener('input', function () {
  const password = this.value;

  const lowercase = /[a-z]/;
  const uppercase = /[A-Z]/;
  const numbers = /[0-9]/;
  const specialCharacters = /[!,@,#,$,%,^,&,*,?,_,(,),-,+,=,~]/;

  let strength = 0;

  // Check for lowercase letter
  if (lowercase.test(password)) {
    document.getElementById('lowercase').className = 'text-primary';
    strength++;
  } else {
    document.getElementById('lowercase').className = 'text-gray-500';
  }

  // Check for uppercase letter
  if (uppercase.test(password)) {
    document.getElementById('uppercase').className = 'text-primary';
    strength++;
  } else {
    document.getElementById('uppercase').className = 'text-gray-500';
  }

  // Check for number
  if (numbers.test(password)) {
    document.getElementById('number').className = 'text-primary';
    strength++;
  } else {
    document.getElementById('number').className = 'text-gray-500';
  }

  // Check for special character
  if (specialCharacters.test(password)) {
    document.getElementById('special').className = 'text-primary';
    strength++;
  } else {
    document.getElementById('special').className = 'text-gray-500';
  }

  // Check for password length
  const lengthIndicator = document.getElementById('length');
  const strengthMessage = document.getElementById('strengthMessage');
  const submitButton = document.getElementById('submitbutton');

  if (password.length >= 8) {
    lengthIndicator.className = 'text-primary';
  } else {
    lengthIndicator.className = 'text-gray-500';
    strengthMessage.textContent = 'Password must be at least 8 characters long.';
    strengthMessage.className = 'text-error';
  }

  // Enable or disable the submit button based on password strength
  if (strength === 4 && password.length >= 8) {
    submitButton.disabled = false;
    submitButton.className = 'w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600';
    strengthMessage.textContent = 'Password strength: Very Strong';
    strengthMessage.className = 'text-primary';
  } else {
    submitButton.disabled = true;
    submitButton.className = 'w-full bg-gray-300 text-gray-500 py-2 px-4 rounded-md cursor-not-allowed';
    if (strength === 3) {
      strengthMessage.textContent = 'Password strength: Strong';
      strengthMessage.className = 'text-secondary';
    } else if (strength === 2) {
      strengthMessage.textContent = 'Password strength: Moderate';
      strengthMessage.className = 'text-warning';
    } else if (strength === 1) {
      strengthMessage.textContent = 'Password strength: Weak';
      strengthMessage.className = 'text-error';
    } else {
      strengthMessage.textContent = 'Password strength: Very Weak';
      strengthMessage.className = 'text-error';
    }
  }
});