document.addEventListener("DOMContentLoaded", () => {
  const otpFields = document.querySelectorAll(".otp-field");
  const keypadButtons = document.querySelectorAll(".keypad-btn");
  const clearButton = document.querySelector(".clear-btn");

  let currentIndex = 0;

  // Add event listener to keypad buttons
  keypadButtons.forEach((button) => {
    button.addEventListener("click", () => {
      if (currentIndex < otpFields.length) {
        otpFields[currentIndex].value = button.textContent;
        currentIndex++;
      }
    });
  });

  // Clear all OTP fields
  clearButton.addEventListener("click", () => {
    otpFields.forEach((field) => (field.value = ""));
    currentIndex = 0;
  });
});