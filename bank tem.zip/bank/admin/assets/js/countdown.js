document.addEventListener("DOMContentLoaded", function () {
    let countdownTime = 15 * 60; // 15 minutes in seconds
    const countdownDisplay = document.getElementById("countdownTimer");

    function updateCountdown() {
        let minutes = Math.floor(countdownTime / 60);
        let seconds = countdownTime % 60;
        countdownDisplay.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        
        if (countdownTime <= 0) {
            window.location.href = "logout.php"; // Redirect to logout page
        } else {
            countdownTime--;
            setTimeout(updateCountdown, 1000);
        }
    }

    updateCountdown(); // Start countdown
});