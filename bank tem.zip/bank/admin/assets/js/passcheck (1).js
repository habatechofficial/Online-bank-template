// Password strength checker and submit button toggle
    document.getElementById('password').addEventListener('input', function () {
      const password = this.value;

      const lowercase = /[a-z]/;
      const uppercase = /[A-Z]/;
      const numbers = /[0-9]/;
      const specialCharacters = /[!,@,#,$,%,^,&,*,?,_,(,),-,+,=,~]/;

      let strength = 0;

      if (lowercase.test(password)) {
        document.getElementById('lowercase').className = 'text-primary';
        strength++;
      } else {
        document.getElementById('lowercase').className = 'text-gray-500';
      }

      if (uppercase.test(password)) {
        document.getElementById('uppercase').className = 'text-primary';
        strength++;
      } else {
        document.getElementById('uppercase').className = 'text-gray-500';
      }

      if (numbers.test(password)) {
        document.getElementById('number').className = 'text-primary';
        strength++;
      } else {
        document.getElementById('number').className = 'text-gray-500';
      }

      if (specialCharacters.test(password)) {
        document.getElementById('special').className = 'text-primary';
        strength++;
      } else {
        document.getElementById('special').className = 'text-gray-500';
      }

      const submitButton = document.getElementById('submitbutton');
      const strengthMessage = document.getElementById('strengthMessage');

      if (strength === 4 && password.length >= 8) {
        submitButton.disabled = false;
        submitButton.className = 'w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600';
        strengthMessage.textContent = 'Password strength: Very Strong';
        strengthMessage.className = 'text-secondary';
      } else {
        submitButton.disabled = true;
        submitButton.className = 'w-full bg-gray-300 text-gray-500 py-2 px-4 rounded-md cursor-not-allowed';
        if (strength === 3) {
          strengthMessage.textContent = 'Password strength: Strong';
          strengthMessage.className = 'text-secondary';
        } else if (strength === 2) {
          strengthMessage.textContent = 'Password strength: Moderate';
          strengthMessage.className = 'text-secondary';
        } else if (strength === 1) {
          strengthMessage.textContent = 'Password strength: Weak';
          strengthMessage.className = 'text-warning';
        } else {
          strengthMessage.textContent = 'Password strength: Very Weak';
          strengthMessage.className = 'text-error';
        }
      }
    });