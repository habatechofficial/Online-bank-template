<?php
// Include your DATABASE_CONNECT class
require_once('__TMP__/connect.php');

// Initialize database connection
$db = new DATABASE_CONNECT();
$mysqli = new mysqli($db->connect[0], $db->connect[1], $db->connect[2], $db->connect[3]);

// Check if connection is successful
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Query to get pending loan applications
$query = "
    SELECT loans.loan_id, loans.loan_amount, loans.application_date, loans.status, accounts.account_no, accounts.firstname, accounts.lastname
    FROM loans
    JOIN accounts ON loans.account_no = accounts.account_no
    WHERE loans.status = 'pending'
    ORDER BY loans.application_date DESC
";
$result = $mysqli->query($query);

// Fetch the result as an associative array
$loans = [];
while ($loan = $result->fetch_assoc()) {
    $loans[] = $loan;
}

// Return the result as JSON
echo json_encode($loans);
?>