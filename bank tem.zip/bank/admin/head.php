<!DOCTYPE html>
<html lang="en" class="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Profile | RamzBank</title>

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
    }
  </script>

  <!-- Boxicons CDN -->
  <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
  <style>
    /* Smooth transition */
    .transition-all {
      transition: all 0.3s ease;
    }

    /* Sidebar styling */
    .sidebar {
      transition: width 0.3s ease;
      width: 16rem;
      overflow: hidden;
    }

    .sidebar-collapsed {
      width: 5rem !important;
    }

    /* Sidebar text fade */
    .sidebar-text {
      transition: opacity 0.3s ease;
      opacity: 1;
    }

    .sidebar-collapsed .sidebar-text {
      opacity: 0;
    }

    .sidebar-collapsed:hover .sidebar-text {
      opacity: 1;
    }

    /* Dropdown chevron rotation */
    .dropdown-chevron {
      transition: transform 0.3s ease;
    }

    .rotate-180 {
      transform: rotate(180deg);
    }

    /* Preloader */
    .preloader {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(255, 255, 255, 0.7);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .preloader div {
      width: 50px;
      height: 50px;
      border: 5px solid transparent;
      border-top: 5px solid #007bff;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
  <style>
.sidebar-link {
  display: block;
  padding: 0.5rem 1rem;
  border-radius: 0.375rem;
  color: #4B5563; /* Gray 700 */
  font-weight: 500;
  transition: background 0.3s, color 0.3s;
}
.sidebar-link:hover {
  background-color: #3B82F6; /* Blue-500 */
  color: white;
}
.dark .sidebar-link {
  color: #D1D5DB; /* Gray 300 */
}
.dark .sidebar-link:hover {
  background-color: #2563EB; /* Blue-600 */
}
</style>
</head>