<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">
<?php include('sidebar.php'); ?>

<div class="flex-1 flex flex-col">
  <?php include('topbar.php'); ?>

  <main class="flex-1 p-6">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Two-Factor Authentication (2FA)</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">Enable 2FA</h2>

      <p class="text-gray-600 dark:text-gray-400 mb-4">Protect your account by enabling two-factor authentication using an authenticator app.</p>

      <div class="flex items-center justify-center mb-6">
        <img src="assets/qr-code-placeholder.png" alt="QR Code" class="w-48 h-48">
      </div>

      <div class="space-y-4">
        <div>
          <label class="block text-gray-700 dark:text-gray-300 mb-1">Enter 2FA Code</label>
          <input type="text" name="2fa_code" class="w-full p-2 border rounded dark:bg-gray-700 dark:border-gray-600 dark:text-white" placeholder="123456">
        </div>

        <button class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">Enable 2FA</button>
      </div>
    </div>
  </main>
</div>

<?php include('scripts.php'); ?>
</body>
</html>