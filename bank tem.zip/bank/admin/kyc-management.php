<?php
// kyc-management.php
?>

<!-- Head -->
<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="flex-1 flex flex-col min-h-screen">

  <!-- Topbar -->
  <?php include('topbar.php'); ?>

  <!-- KYC Management -->
  <main class="flex-1 p-6">
    <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-6">KYC Management</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <div class="overflow-x-auto">
        <table class="min-w-full table-auto">
          <thead>
            <tr class="text-gray-700 dark:text-gray-300 text-left">
              <th class="py-3 px-6">#</th>
              <th class="py-3 px-6">User</th>
              <th class="py-3 px-6">Document Type</th>
              <th class="py-3 px-6">Status</th>
              <th class="py-3 px-6">Action</th>
            </tr>
          </thead>
          <tbody class="text-gray-600 dark:text-gray-400">
            <?php for($i=1;$i<=5;$i++): ?>
            <tr class="border-b dark:border-gray-700">
              <td class="py-4 px-6"><?php echo $i; ?></td>
              <td class="py-4 px-6">John Doe <?php echo $i; ?></td>
              <td class="py-4 px-6">Passport</td>
              <td class="py-4 px-6">
                <span class="inline-block px-2 py-1 text-sm bg-yellow-100 text-yellow-600 rounded-full">Pending</span>
              </td>
              <td class="py-4 px-6 flex space-x-3">
                <button class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 text-sm">Approve</button>
                <button class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 text-sm">Reject</button>
              </td>
            </tr>
            <?php endfor; ?>
          </tbody>
        </table>
      </div>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>

</body>
</html>