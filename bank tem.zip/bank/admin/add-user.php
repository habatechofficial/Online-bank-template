<?php
// add-user.php
?>

<!-- Head -->
<?php include('head.php'); ?>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen flex">

<!-- Sidebar -->
<?php include('sidebar.php'); ?>

<!-- Main Content -->
<div class="flex-1 flex flex-col min-h-screen">

  <!-- Topbar -->
  <?php include('topbar.php'); ?>

  <!-- Add User Form -->
  <main class="flex-1 p-6">
    <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-6">Add New User</h1>

    <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
      <form class="space-y-6" action="save-user.php" method="POST">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Full Name</label>
            <input type="text" name="fullname" required class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
          </div>

          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Email</label>
            <input type="email" name="email" required class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
          </div>

          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Phone</label>
            <input type="text" name="phone" required class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
          </div>

          <div>
            <label class="block text-gray-700 dark:text-gray-300 mb-2">Password</label>
            <input type="password" name="password" required class="w-full px-4 py-2 rounded border dark:bg-gray-700 dark:border-gray-600 dark:text-white" />
          </div>
        </div>

        <div class="flex justify-end">
          <button type="submit" class="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">Create User</button>
        </div>
      </form>
    </div>

  </main>
</div>

<?php include('scripts.php'); ?>

</body>
</html>